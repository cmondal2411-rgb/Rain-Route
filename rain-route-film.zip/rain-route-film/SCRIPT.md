# Rain Route — Director's Treatment

- **Promise:** Rain Route demonstrates that a route with a few extra minutes can be preferred when local waterlogging reports show substantially lower rain-related risk.
- **Audience:** Class 11 science exhibition visitors; clear enough to understand without narration or sound.
- **Format and runtime:** 16:9 landscape for a projector or presentation; 30 seconds, six 5-second scenes.
- **Identity:** Carry over the app's warm paper, deep blue-green, teal, and coral palette. Use Space Grotesk for display type, Manrope for supporting copy, and DM Mono for measured data.
- **Hero:** A single drawn road network whose route line bends around a pool of water, then transforms into the road-and-rain-cloud mark.
- **Motion:** Animated SVG route tracing, sharp scale-through transitions, and data labels that reconfigure from distance/time to rain risk.
- **Arc:** A flooded shortcut creates the question; three route facts establish the contrast; the rain-adjusted score explains the change; local reports reveal the prototype's source; the end card states the takeaway and limits.
- **Payoff:** The separated roads resolve into one compact road-and-cloud mark. The opening question returns as a plain-language answer.
- **Sound:** One instrumental bed, curious and lightly rhythmic, with a gentle lift near the route recommendation. No voiceover or sound effects. Music-to-cut alignment is unverified until the soundtrack exists.

## Timeline overview

| Time | Focus | Main motion | Composition | Handoff |
|---|---|---|---|---|
| 0–5s | A shortcut meets a flood pool | A teal route snaps into a puddle; “SHORTEST?” lands in three quick beats | Tight, oblique local-road diagram with a huge water circle | Puddle circle expands into the next shot |
| 5–10s | Route A's measured problem | The flooded path pulls back to reveal 2.4 km / 8 min beside 12 cm / 180 min | Asymmetric map close-up; coral hazard owns the right half | The hazard ring becomes a junction |
| 10–15s | Three routes compared | A, B, C draw in order; B curves around the obstruction and settles in teal | Wide, top-down map with three distinct colored paths | Teal route line draws into a scoring scale |
| 15–20s | Rain Mode changes the winner | The cost scale flips from normal to rain-adjusted; the selected route changes A → B | Split graphic, bold large numerals, compact factor marks | B's endpoint becomes a report-location pin |
| 20–25s | Local observations become memory | A report card unfolds into three recurring location marks; the risk inputs orbit then sort | Layered paper/report collage, no interface controls | Three location marks fold into the road-cloud logo |
| 25–30s | Answer and prototype boundary | Logo resolves; takeaway and safety disclaimer appear; route loops into opening geometry | Centered end card on deep blue-green field with cream lockup | A map-line arc reconnects to the opening route |

## Shot-by-shot script

### Shot 01 / 00.00–05.00s / 5.00s — “SHORTEST?”

- **Purpose:** Establish the core question immediately: a short road can be a poor choice during heavy rain.
- **Exact on-screen copy and holds:**
  - `SHORTEST?` begins its three-beat reveal at 00.25s and is fully readable by 01.10s.
  - `A familiar road. A different problem in rain.` appears at 02.10s and stays readable through 04.35s.
  - No narration.
- **Composition:** Open on a close, angled crop of two cream road bands crossing a warm paper field. A large, translucent teal puddle sits just off center. The route's teal dash starts in the lower-left; the headline owns the upper-left safe region; the puddle owns the middle-right.
- **Artistic idea:** The route line behaves like a confident shortcut until its tip touches the puddle and visibly kinks around the water's edge.
- **Timed choreography:**
  - 00.00–00.25: A small coral rain mark impacts the cream road; concentric rings spread from the actual contact point.
  - 00.25–00.80: The route draws rapidly toward the puddle; the word `SHORTEST?` snaps in as three line fragments that lock together.
  - 00.80–01.60: The route tip contacts the water circle and bends; three small ripples pulse outward.
  - 01.60–02.10: Camera pulls back slightly to reveal the junction and an alternate road.
  - 02.10–03.10: Supporting line is uncovered by a short mask wipe.
  - 03.10–04.20: The water surface grows across frame, keeping the route bend visible as a dark teal silhouette.
  - 04.20–05.00: The circle scales through camera center and blurs at the edge while the route stroke stays visible into the cut.
- **Transition contract:** The expanding puddle circle fills the frame and becomes the coral-outlined hazard marker in Shot 02; its center and scale match across the cut. Combine scale-through with a diagonal paper split.
- **Assets and technique:** SVG roads, route stroke, water circle, three fixed ripple rings, mask-revealed type; no photography required.
- **Sound intent:** Instrumental begins with a light pulse; the puddle impact is visual only. Cut accent is planned but unverified.

### Shot 02 / 05.00–10.00s / 5.00s — “ROUTE A: 2.4 KM”

- **Purpose:** Show why the shortest route is attractive under normal distance/time comparison, then make its measured waterlogging visible.
- **Exact on-screen copy and holds:**
  - `ROUTE A` and `2.4 km · 8 min normal` reveal at 05.35s; hold to 09.65s.
  - `12 cm water · 180 min` appears at 07.10s; hold to 09.65s.
  - `High rain risk · demonstration data` appears at 08.15s; hold to 09.65s.
  - No narration.
- **Composition:** Start with the puddle filling most of the right half. The map pulls back to an asymmetric top-down view: Route A is coral and runs diagonally from lower-left to upper-right through the water zone. Data occupies a distinct lower-left strip, away from the hazard marker.
- **Artistic idea:** The big `2.4` numeral is cut by the road itself; the route's attractive short length visually collides with a 12 cm depth gauge.
- **Timed choreography:**
  - 05.00–05.45: The Shot 01 water circle contracts into the center of the flood marker while a two-panel cream map unfolds behind it.
  - 05.45–06.20: Coral Route A traces across the map in one uninterrupted stroke; `2.4 km` punches in, followed by `8 min`.
  - 06.20–07.05: Camera glides along the short route and slows at the flooded segment.
  - 07.05–07.75: A vertical measuring rule grows from the road; `12 cm water` resolves beside it.
  - 07.75–08.35: A short duration bar extends across three marked hours; `180 min` lands at the end.
  - 08.35–09.20: The route line dims at the flood boundary; `High rain risk` appears in a coral label.
  - 09.20–10.00: Hazard marker rotates into a four-way junction; camera makes a sharp pull-through along its center.
- **Transition contract:** The expanding junction ring becomes the node where the three routes branch in Shot 03. Combine 3D-like marker flip with a split road reveal; retain the same node coordinates.
- **Assets and technique:** SVG map paths and depth gauge; typography overlay; warm paper becomes a flat cream map plane.
- **Sound intent:** Continue the same instrumental; a low rhythmic accent may support the depth reading, alignment unverified.

### Shot 03 / 10.00–15.00s / 5.00s — “THREE ROUTES. THREE CONDITIONS.”

- **Purpose:** Compare all supplied demonstration routes and show Route B's rain-related advantage without implying certification.
- **Exact on-screen copy and holds:**
  - `A · 2.4 km · 8 min · 12 cm / 180 min` reveals at 10.50s.
  - `B · 3.0 km · 10 min · 2 cm / 20 min` reveals at 11.45s.
  - `C · 2.7 km · 9 min · 5 cm / 60 min` reveals at 12.40s.
  - `Demo comparison` appears at 13.45s and holds to 14.70s.
  - No narration.
- **Composition:** A wide, clean top-down street network replaces the tight view. The shared junction is centered. Route A (coral) is shortest and crosses the marked flood area; Route B (teal) makes a longer arc; Route C (ochre) takes a moderate bend. Text appears in three staggered, non-overlapping label zones around the routes.
- **Artistic idea:** The route comparison is a choreographed line-drawing contest: A wins distance but stalls at water, B travels farther around it, and C threads between them.
- **Timed choreography:**
  - 10.00–10.40: The junction ring opens into three streets; the camera pulls back to reveal the full route field.
  - 10.40–11.10: Coral A traces first and stops at the water; its `2.4 km` numeral snaps into place.
  - 11.10–12.00: Teal B traces around the hazard in a sweeping arc; `3.0 km` and `2 cm / 20 min` appear one at a time.
  - 12.00–12.90: Ochre C draws a middle path; its `5 cm / 60 min` callout settles near its endpoint.
  - 12.90–13.70: The three time-and-depth labels re-order into clean columns while all route lines remain visible.
  - 13.70–14.40: Route A flashes once to mark “shortest”; Route B brightens and gains a fine cream outline to mark “lower demo rain risk.”
  - 14.40–15.00: Teal B lifts from the map plane toward camera and becomes a long horizontal scoring line.
- **Transition contract:** The B path lifts and straightens into the score baseline for Shot 04. Combine route-plane perspective lift with a short cream panel unfold; the teal color and start/end points remain continuous.
- **Assets and technique:** SVG map with all three roads and flood area; drawn path animation; numeric labels in DM Mono; route colors remain consistent.
- **Sound intent:** Same instrumental; no asserted sync.

### Shot 04 / 15.00–20.00s / 5.00s — “RAIN MODE CHANGES THE COST”

- **Purpose:** Explain the transparent prototype logic and visibly switch the winner from Route A in normal mode to Route B in Rain Mode.
- **Exact on-screen copy and holds:**
  - `NORMAL COST` appears at 15.25s.
  - `Rain-adjusted cost` replaces it at 17.20s.
  - `Depth · duration · passability · report recency` appears in four sequential beats from 16.00s to 18.40s.
  - `A shortest → B lower rain-risk score` appears at 18.55s and holds to 19.65s.
  - `Prototype weights · not a certified safety recommendation` appears at 19.00s and holds to 19.75s.
  - No narration.
- **Composition:** Split graphic, half cream and half deep blue-green. The left side carries a large `A` and a short normal-cost scale; the right side carries a long score track with depth, duration, passability, and recency as four readable markers. No detailed equation is presented as a scientifically validated formula.
- **Artistic idea:** A broad switch-shaped score rail visibly reweights itself; the A marker moves from lowest on a plain distance/time ruler to B on the rain-adjusted ruler.
- **Timed choreography:**
  - 15.00–15.45: Teal route line from Shot 03 clicks into a horizontal ruler; `NORMAL COST` cuts in at the left.
  - 15.45–16.25: A / B / C markers slide into a normal distance-time order; A snaps into the selected slot.
  - 16.25–17.15: Four small inputs enter individually—water-depth column, duration arc, passability bar, recency clock—each tethered to the score rail.
  - 17.15–17.85: Cream half folds behind the dark field; title changes to `Rain-adjusted cost` through a masked replacement, not a fade.
  - 17.85–18.50: Risk markers shift; A's coral marker lifts while B's teal marker travels into the lower-score slot.
  - 18.50–19.25: The explanatory copy resolves; `Prototype weights` note appears separately in a small but legible line.
  - 19.25–20.00: B's selected marker expands into a location pin; a soft polygon wipe carries the pin forward.
- **Transition contract:** The B score marker stretches vertically into a report-location pin that opens Shot 05. Combine scale-to-pin and a diagonal color-panel wipe.
- **Assets and technique:** Graphic score rail and SVG input marks, mask type, per-second layout morph. All formula assumptions are labelled prototype assumptions.
- **Sound intent:** Same instrumental, intended to lift at selection, not verified.

### Shot 05 / 20.00–25.00s / 5.00s — “LOCAL REPORTS BUILD RAIN MEMORY”

- **Purpose:** Show that locally submitted road observations feed recurring-area memory and the scoring model; keep the local/browser-only data boundary clear.
- **Exact on-screen copy and holds:**
  - `OBSERVE → REPORT → REMEMBER` reveals in three separate beats from 20.30s to 22.10s.
  - `Water depth · duration · passability · recency` appears at 22.15s.
  - `Saved on this device in the prototype` appears at 23.20s.
  - `Not live rainfall or live traffic` appears at 24.00s and holds to 24.80s.
  - No narration.
- **Composition:** The map pin lands on a layered cream-paper report slip slightly left of center. To its right, three tiny local road marks stack vertically; a small amber “repeat” bracket visually groups only observations for the same named location. Deep blue-green field holds behind the papers.
- **Artistic idea:** A single report's punched location pin becomes a recurring-location index tab; repeated marks gather into a memory register rather than implying a citywide live feed.
- **Timed choreography:**
  - 20.00–20.45: Pin from Shot 04 lands; concentric paper rings appear at the location.
  - 20.45–21.20: A report slip unfolds on a diagonal hinge with fields shown as decorative lines, not interactive form widgets.
  - 21.20–22.25: Three local observation marks stamp down one after another; matching road names align into a stack.
  - 22.25–23.15: Four scoring inputs orbit briefly around the stack, then sort into a single vertical list.
  - 23.15–24.00: Copy confirms device-local saving; the report slip folds into the route-map shape.
  - 24.00–24.75: The live-data limitation appears while background rain marks visibly fade to empty outline, clarifying that no live feed is present.
  - 24.75–25.00: Folded map narrows into a road ribbon that rises toward the center.
- **Transition contract:** The road ribbon arches over and combines with the score pin to form the road-and-cloud mark in Shot 06. Match its teal stroke, center, and upward curve; pair a paper fold with a circular reveal.
- **Assets and technique:** CSS/SVG paper card, location-pin, static report strokes and repeat bracket; no user-entered data in film.
- **Sound intent:** Same instrumental; a warm lift may accompany the report stamp, alignment unverified.

### Shot 06 / 25.00–30.00s / 5.00s — “SHORTEST ISN'T ALWAYS THE BEST DURING RAIN.”

- **Purpose:** End on the project message, what it is, and a clear safety limitation.
- **Exact on-screen copy and holds:**
  - `RAIN ROUTE` resolves by 25.70s.
  - `Shortest isn't always the best during rain.` reveals by 26.60s and holds through 29.75s.
  - `Class 11 science exhibition · educational prototype · demonstration data only` appears by 27.70s and holds to 29.75s.
  - `Road conditions change quickly. Never enter dangerous or flooded areas based only on app information.` appears by 28.25s and remains until 29.90s.
  - No narration.
- **Composition:** Distinct from all previous asymmetric map shots: centered road-and-rain-cloud mark on a deep blue-green field, cream logo lettering, small coral rain marks, and ample negative space. The end message sits below the mark in two broad lines.
- **Artistic idea:** The roads stop competing and become a single emblem; the question from the opener resolves as a statement. One short coral rain stroke leaves a loop carrier that redraws the first route.
- **Timed choreography:**
  - 25.00–25.55: Map ribbon and pin complete the cloud-over-road mark through a three-part snap: cloud arc, road split, rain strokes.
  - 25.55–26.40: `RAIN ROUTE` appears as one confident lockup; fine cream grid marks retract outward.
  - 26.40–27.30: Takeaway copy reveals line-by-line with a mask; a coral route point lands under “best.”
  - 27.30–28.20: Class 11 and educational-prototype label resolve in a compact mono line.
  - 28.20–29.35: Full safety notice fades in over an opaque dark footer band with sufficient contrast.
  - 29.35–30.00: All other marks clear; the coral rain stroke arcs into the exact puddle-circle position of Shot 01, visible throughout the handoff so the loop starts with no empty frame.
- **Transition contract:** Loop back to Shot 01 by matching the returning coral stroke and puddle center to its first impact point. Use one small scale-through and a paper-color reveal; no blank field or dead tail.
- **Assets and technique:** Custom SVG road/cloud mark drawn from the existing route motif; typography lockup; consistent warm cream, deep blue-green, teal, coral. No external logo or footage.
- **Sound intent:** Instrumental resolves without a claimed hard beat alignment; opening pulse should feel related to the loop point, alignment unverified.

## Pre-code review

- Adjacent shots vary: macro water/angled road; asymmetrical route close-up; wide top-down network; split score graphic; layered report collage; centered end lockup.
- Each 5-second scene includes multiple timed visual changes and a late transition event; no scene is a static title card or ends on an empty field.
- Route A/B/C values match the supplied demonstration data. Rain Mode's change in preference is presented as a prototype comparison, not a certified recommendation.
- The local memory section explicitly says device-local prototype storage. No live map, GPS, traffic, or rainfall claim is made.
- The final 30-second total equals six scene durations of 5,000 ms each. Any material timing change must be reflected in this script before music generation.